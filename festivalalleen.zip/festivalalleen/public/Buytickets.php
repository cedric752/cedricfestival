<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="engine1/style.css" />
    <script type="text/javascript" src="engine1/jquery.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Homepage</title>
</head>

<body>
<div id="container">
    <div id="header">
        <ul>
            <li><a href="Contact.php">Contact</a></li>
            <li><a href="About.php">About</a></li>
            <a href="#" ><img id="shoppingcart" src="images/basket_shopping_ecommerce-512.png"></a>
        </ul>
        <h1> Graafschap festivals </h1>
    </div>
    <div id="content">
        <h1> Content </h1>
    </div>
    <div id="footer">
        Hier komt de footer
    </div>
</div>
</body>
</html>






