
<html>
<head>

</head>
<body>
<form action="profielPagina.php" method="get">
    <table>
        <tr><td> Username: </td><td><input type="text" id="username" name="username"></td></tr>
        <tr><td><input type="submit" id="submit" name="submit" value="View Profile!" </td></tr>
    </table>

</form>
</body>
</html>
