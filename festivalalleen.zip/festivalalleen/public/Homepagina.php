<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="engine1/style.css" />
    <script type="text/javascript" src="engine1/jquery.js"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Homepage</title>
</head>

<body>
<div id="container">
    <div id="header">
        <ul>
            <li><a href="Contact.php">Contact</a></li>
            <li><a href="About.php">About</a></li>
            <li><a href="Buytickets.php">Buy Tickets</a></li>
            <li><a href="Login.php">Login</a></li>
            <li><img src="images/img_411076.png" id="loginFoto"></li>
        </ul>
        <h1> Graafschap festivals </h1>
    </div>
    <div id="content">
        <div id="wowslider-container1">
            <div class="ws_images"><ul>
                    <li><img src="data1/images/960x0.jpg" alt="960x0" title="" id="wows1_0"/></li>
                    <li><img src="data1/images/grootstefestivalsnederland.jpg" alt="Grootste-festivals-nederland" title="" id="wows1_1"/></li>
                    <li><a href="http://wowslider.net"><img src="data1/images/maxresdefault_1.jpg" alt="javascript photo gallery" title="" id="wows1_2"/></a></li>
                    <li><img src="data1/images/summerconcertslist.jpg" alt="summer-concerts-list" title="" id="wows1_3"/></li>
                </ul></div>
            <div class="ws_bullets"><div>
                    <a href="#" title=""><span><img src="data1/tooltips/960x0.jpg" alt="960x0"/>1</span></a>
                    <a href="#" title=""><span><img src="data1/tooltips/grootstefestivalsnederland.jpg" alt="Grootste-festivals-nederland"/>2</span></a>
                    <a href="#" title=""><span><img src="data1/tooltips/maxresdefault_1.jpg" alt="maxresdefault (1)"/>3</span></a>
                    <a href="#" title=""><span><img src="data1/tooltips/summerconcertslist.jpg" alt="summer-concerts-list"/>4</span></a>
                </div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">jquery slideshow</a> by WOWSlider.com v9.0</div>
            <div class="ws_shadow"></div>
        </div>
        <script type="text/javascript" src="engine1/wowslider.js"></script>
        <script type="text/javascript" src="engine1/script.js"></script>
    </div>
    <div id="footer">
        Hier komt de footer
    </div>
</div>
</body>
</html>

