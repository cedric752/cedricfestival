<html>
<head>
<title><?php echo $username; ?>'s Profile</title>
</head>
<body>

<?php
include_once('../database/DBFestival.php');

//kijk of de form is gesubmit
if(isset($_GET['username']))
{
    $username = $_GET['username'];
    $userquery = mysqli_query("SELECT * FROM klanten WHERE Username='$username'", $db) or die("The query kon niet worden uitgevoerd probeer later opnieuw");
    if(mysqli_num_rows($userquery) != 1)
    {
        die ("That username could not be found");
    }
    while(mysqli_fetch_array($userquery, MYSQLI_ASSOC))
    {
        $dbusername = $row['Username'];
        $email = $row['Email'];
        $password = $row['Wachtwoord'];
        $acces = $row['acces'];
    }

    if($username != $dbusername)
    {
        die("There has been a error");
    }
    //Kijk naar de acces
    if($acces == 0)
    {
        $admin = "This user is not an administrator";
    } else {
        $admin = "This user an administrator";
    }
    ?>

    <h2><?php echo $username; ?>'s Profile</h2><br />
    <table>
        <tr><td>Username: </td><td> <?php echo $username; ?></td></tr>
        <tr><td>Email: </td><td> <?php echo $email; ?></td></tr>
        <tr><td>Acces: </td><td> <?php echo $acces; ?></td></tr>
    </table>

<?php

} else die("Je hebt een gebruikersnaam nodig");

?>

</body>
</html>
