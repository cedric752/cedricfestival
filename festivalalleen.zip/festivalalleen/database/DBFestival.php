<?php
session_start();

// initalizeren van variabele
$username = "";
$email    = "";
$errors = array();

// connectie met de database
$db = mysqli_connect('localhost', 'festival', 'VanLenthe2017', 'festival');

// REGISTER USER
if (isset($_POST['reg_user'])) {
    // ontvang alle invoer
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
    $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

    // form: zorg ervoor dat de form correct gevuld is
    // door (array_push()) toe te voegen voegt hij de error toe aan de errors array
    if (empty($username)) { array_push($errors, "Gebruikersnaam is verplicht"); }
    if (empty($email)) { array_push($errors, "Emailadres is verplicht"); }
    if (empty($password_1)) { array_push($errors, "Wachtwoord is verplicht"); }
    if ($password_1 != $password_2) {
        array_push($errors, "De wachtwoorden komen niet overeen");
    }

    // check de database of de user niet al bestaat met die email en gebruikersnaam
    $user_check_query = "SELECT * FROM klanten WHERE Username='$username' OR Email='$email' LIMIT 1";
    $result = mysqli_query($db, $user_check_query);
    $user = mysqli_fetch_assoc($result);

    if ($user) { // als de user al bestaat
        if ($user['username'] === $username) {
            array_push($errors, "Gebruikersnaam is al in gebruik");
        }

        if ($user['email'] === $email) {
            array_push($errors, "Emailadres is al in gebruik");
        }
    }

    // registreer gebruiker als er geen fouten in de form zitten
    if (count($errors) == 0) {
        $password = md5($password_1);//encrypt het wachtwoord voordat het word opgeslagen in de database

        $query = "INSERT INTO klanten (Username, Email, Wachtwoord) 
  			  VALUES('$username', '$email', '$password')";
        mysqli_query($db, $query);
        $_SESSION['username'] = $username;
        $_SESSION['success'] = "Je bent geregistreert";
        header('location: Registreer.php');

    }
}


// USER LATEN INLOGGEN
if (isset($_POST['login_user'])) {
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);

    if (empty($username)) {
        array_push($errors, "Gebruikersnaam is verplicht");
    }
    if (empty($password)) {
        array_push($errors, "Wachtwoord is verplicht");
    }

    if (count($errors) == 0) {
        $password = md5($password);
        $query = "SELECT * FROM klanten WHERE Username='$username' AND Wachtwoord='$password'";
        $results = mysqli_query($db, $query);
        if (mysqli_num_rows($results) == 1) {
            $_SESSION['username'] = $username;
            $_SESSION['success'] = "Je bent ingelogd";
            header('location: Homepagina.php');
        }else {
            array_push($errors, "Verkeerde gebruikersnaam/wachtwoord");
        }
    }
}

?>

